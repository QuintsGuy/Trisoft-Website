import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-header-dialog',
  standalone: true,
  imports: [],
  templateUrl: './header-dialog.component.html',
  styleUrl: './header-dialog.component.css'
})
export class HeaderDialogComponent {
  constructor(public dialogRef: MatDialogRef<HeaderDialogComponent>) {}

  onNoClick(): void {
    this.dialogRef.close();
  }
}
